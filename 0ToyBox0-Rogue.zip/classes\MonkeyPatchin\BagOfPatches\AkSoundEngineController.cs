﻿// borrowed shamelessly and enhanced from Bag of Tricks https://www.nexusmods.com/pathfinderkingmaker/mods/26, which is under the MIT License
namespace ToyBox.BagOfPatches {
    internal class AkSoundEngineController {
    }
}